<?php
class PronounceableWord_Configuration_LinkedLetters {
    public $lettersWithLinkedLetters = array(
        'a' => 'bcdgiklmnprstvy',
        'b' => 'aeilorstuy',
        'c' => 'acehiklortu',
        'd' => 'aeiorsu',
        'e' => 'acdeilmnprstvxy',
        'f' => 'aefilortu',
        'g' => 'aeghilnorsu',
        'h' => 'aeiortu',
        'i' => 'acdefglmnorstv',
        'k' => 'aeilnos',
        'l' => 'adefilostuy',
        'm' => 'abeimoprsuy',
        'n' => 'acdegiosty',
        'o' => 'cdfklmnoprstuvw',
        'p' => 'aehiloprstu',
        'r' => 'acdegilmnorstuy',
        's' => 'acehilopstu',
        't' => 'aehilorstuy',
        'u' => 'abcdegilmnprst',
        'v' => 'aeino',
        'w' => 'aehinos',
        'x' => 'acehiptu',
        'y' => 'eiost',
        'z' => 'aeiloyz',
    );
}
