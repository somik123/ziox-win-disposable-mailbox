<?php
class PronounceableWord_Configuration_LetterTypes {
    public $letterTypesWithLetters = array(
        'voyels' => 'aeiouy',
        'consonants' => 'bcdfghklmnprstvwxz',
    );
}
