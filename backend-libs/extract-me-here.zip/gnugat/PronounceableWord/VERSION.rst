VERSION
=======

The purpose of this file is to point out the version of the PronounceableWord
library.

Current version
---------------

2.0.0
